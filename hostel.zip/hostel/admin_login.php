﻿<?php
session_start();
include("config.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $query = mysqli_query($conn,
"SELECT * FROM admins 
         WHERE email='$email'
         AND password='$password'"
    );

    if (mysqli_num_rows($query) == 1) {
        $_SESSION['admin'] = $email;
        header("Location: admin/dashboard.php");
        exit();
    } else {
        $error = "Invalid Admin Login.";
    }
}
?>

<h2>Admin Login</h2>

<?php if ($error != "") echo "<p style='color:red;'>$error</p>"; ?>

<form method="POST">
    Email:<br>
<input type="email" name="email" required><br><br>

    Password:<br>
<input type="password" name="password" required><br><br>

<button type="submit">Login</button>
</form>
<?php

session_start();

include("config.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);

    $password = trim($_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM admins WHERE email='$email' AND password='$password'");

    if (mysqli_num_rows($query) == 1) {

        $_SESSION['admin'] = $email;

        header("Location: admin/dashboard.php");

        exit();

    } else {

        $error = "Invalid Admin Credentials!";

    }

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Admin Login</title>

<style>

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: linear-gradient(135deg, #f6c23e, #e74a3b);

    display: flex;

    justify-content: center;

    align-items: center;

    height: 100vh;

}

.login-box {

    background: white;

    padding: 40px;

    width: 350px;

    border-radius: 10px;

    box-shadow: 0 10px 25px rgba(0,0,0,0.2);

    text-align: center;

}

.login-box h2 {

    margin-bottom: 25px;

}

input {

    width: 100%;

    padding: 10px;

    margin: 10px 0;

    border-radius: 5px;

    border: 1px solid #ccc;

}

button {

    width: 100%;

    padding: 10px;

    background: #e74a3b;

    border: none;

    color: white;

    font-weight: bold;

    border-radius: 5px;

    cursor: pointer;

}

button:hover {

    background: #c0392b;

}

.error {

    color: red;

    margin-bottom: 10px;

}

</style>

</head>

<body>

<div class="login-box">

    <h2>👨‍💼 Admin Login</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit">Login</button>

    </form>

</div>

</body>

</html>