﻿<?php

function checkRole($allowedRoles) {

    if (!in_array($_SESSION['role'], $allowedRoles)) {
        header("Location: ../index.php");
        exit();
    }

}
  