<?php
include("config.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($email == "" || $password == "") {
        $message = "All fields are required.";
    } else {

        $check = mysqli_query($conn, "SELECT id FROM students WHERE email='$email'");

        if (mysqli_num_rows($check) > 0) {
            $message = "Email already registered.";
        } else {

            $insert = mysqli_query($conn,
"INSERT INTO students (email, password) VALUES ('$email', '$password')"
            );

            if ($insert) {
                $message = "Registration Successful!";
            } else {
                $message = "Registration Failed.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
</head>
<body>

<h2>Student Registration</h2>

<?php if ($message != "") echo "<p>$message</p>"; ?>

<form method="POST">
    Email:<br>
<input type="email" name="email" required><br><br>

    Password:<br>
<input type="password" name="password" required><br><br>

<button type="submit">Register</button>
</form>

<br>
<a href="login.php">Go to Login</a>

</body>
</html>
