<?php
session_start();
require_once 'includes/db.php';

$message = "";

if(isset($_POST['register'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    // HASH PASSWORD
    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    // CHECK EMAIL
    $check = mysqli_query($conn,

"SELECT * FROM users
    WHERE email='$email'");

    if(mysqli_num_rows($check) > 0){

        $message = "Email already exists.";

    }else{

        mysqli_query($conn,

"INSERT INTO users
        (fullname, email, password, role)

        VALUES
        ('$fullname',
'$email',
'$password',
'student')");

        $message = "Registration successful.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Register</title>

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
}

.container{
    width:350px;
    margin:100px auto;
    background:white;
    padding:25px;
    border-radius:10px;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    width:100%;
    padding:12px;
    background:#007bff;
    color:white;
    border:none;
}

.success{
    color:green;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="container">

<h2>Register</h2>

<p class="success">

<?php echo $message; ?>

</p>

<form method="POST">

<input type="text"
name="fullname"
placeholder="Full Name"
required>

<input type="email"
name="email"
placeholder="Email"
required>

<input type="password"
name="password"
placeholder="Password"
required>

<button type="submit"
name="register">

Register

</button>

</form>

</div>

</body>
</html>
