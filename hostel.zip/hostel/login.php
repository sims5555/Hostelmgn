<?php
session_start();
require_once 'includes/db.php';

$message = "";

if(isset($_POST['login'])){

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // GET USER
    $query = mysqli_query($conn,

"SELECT * FROM users
    WHERE email='$email'");

    if(mysqli_num_rows($query) > 0){

        $user = mysqli_fetch_assoc($query);

        // VERIFY HASHED PASSWORD
        if(password_verify($password, $user['password'])){

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = $user['role'];

            // ACTIVITY LOG
            $user_id = $user['id'];

            $activity = "Logged into the system";

            mysqli_query($conn,

"INSERT INTO activity_logs
            (user_id, activity)

            VALUES
            ('$user_id','$activity')");

            // REDIRECT BASED ON ROLE
            if($user['role'] == 'super_admin'){

                header("Location: admin/super_admin/index.php");
                exit;

            }elseif($user['role'] == 'admin'){

                header("Location: admin/admin_panel/index.php");
                exit;

            }else{

                header("Location: student/index.php");
                exit;
            }

        }else{

            $message = "Invalid password.";
        }

    }else{

        $message = "User account not found.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Hostel Management System</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#0f172a;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

.container{
    width:100%;
    max-width:420px;
    background:white;
    padding:35px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.logo{
    text-align:center;
    margin-bottom:25px;
}

.logo h1{
    color:#007bff;
    margin-bottom:10px;
}

.logo p{
    color:#64748b;
    font-size:14px;
}

.error{
    background:#fee2e2;
    color:#dc2626;
    padding:12px;
    border-radius:5px;
    margin-bottom:15px;
    text-align:center;
}

input{
    width:100%;
    padding:14px;
    margin-bottom:15px;
    border:1px solid #cbd5e1;
    border-radius:8px;
    font-size:15px;
}

input:focus{
    outline:none;
    border-color:#007bff;
}

button{
    width:100%;
    padding:14px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-size:16px;
    font-weight:bold;
}

button:hover{
    background:#0056b3;
}

.links{
    margin-top:20px;
    text-align:center;
}

.links a{
    display:block;
    margin-bottom:12px;
    text-decoration:none;
    color:#007bff;
    font-size:14px;
}

.links a:hover{
    text-decoration:underline;
}

.footer{
    margin-top:20px;
    text-align:center;
    color:#94a3b8;
    font-size:13px;
}

</style>

</head>

<body>

<div class="container">

<div class="logo">

<h1>HOSTEL SYSTEM</h1>

<p>
GWU-Hostel Management Platform
</p>

</div>

<?php if(!empty($message)){ ?>

<div class="error">

<?php echo $message; ?>

</div>

<?php } ?>

<form method="POST">

<input type="email"
name="email"
placeholder="Enter Email"
required>

<input type="password"
name="password"
placeholder="Enter Password"
required>

<button type="submit"
name="login">

Login

</button>

</form>

<div class="links">

<a href="forgot_password.php">
Forgot Password?
</a>

<a href="register.php">
Student Registration
</a>

</div>

<div class="footer">

Hostel Management System � 2026

</div>

</div>

</body>
</html>
