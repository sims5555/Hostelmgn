<?php
session_start();
include("config.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $query = mysqli_query($conn,
"SELECT id FROM students 
         WHERE email = '$email'
         AND password = '$password'"
    );

    if (mysqli_num_rows($query) == 1) {

        $_SESSION['student'] = $email;
        header("Location: student/dashboard.php");
        exit();

    } else {
        $error = "Incorrect email or password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>
<body>

<h2>Student Login</h2>

<?php if ($error != "") echo "<p style='color:red;'>$error</p>"; ?>

<form method="POST">
    Email:<br>
<input type="email" name="email" required><br><br>

    Password:<br>
<input type="password" name="password" required><br><br>

<button type="submit">Login</button>
</form>

</body>
</html>
<?php

session_start();

include("config.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);

    $password = trim($_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM students WHERE email='$email' AND password='$password'");

    if (mysqli_num_rows($query) == 1) {

        $_SESSION['student'] = $email;

        header("Location: student/dashboard.php");

        exit();

    } else {

        $error = "Invalid Email or Password!";

    }

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Login</title>

<style>

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: linear-gradient(135deg, #4e73df, #1cc88a);

    display: flex;

    justify-content: center;

    align-items: center;

    height: 100vh;

}

.login-box {

    background: white;

    padding: 40px;

    width: 350px;

    border-radius: 10px;

    box-shadow: 0 10px 25px rgba(0,0,0,0.2);

    text-align: center;

}

.login-box h2 {

    margin-bottom: 25px;

}

input {

    width: 100%;

    padding: 10px;

    margin: 10px 0;

    border-radius: 5px;

    border: 1px solid #ccc;

}

button {

    width: 100%;

    padding: 10px;

    background: #4e73df;

    border: none;

    color: white;

    font-weight: bold;

    border-radius: 5px;

    cursor: pointer;

}

button:hover {

    background: #2e59d9;

}

.error {

    color: red;

    margin-bottom: 10px;

}

.link {

    margin-top: 15px;

}

</style>

</head>

<body>

<div class="login-box">

    <h2>🎓 Student Login</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit">Login</button>

    </form>

    <div class="link">

        <a href="register.php">Create Account</a>

    </div>

</div>

</body>

</html>