<?php

$servername = "sql111.infinityfree.com";

$username   = "if0_41200674";

$password   = "Selenane12";

$database   = "if0_41200674_ifo_";   // <-- IMPORTANT (with underscore)

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {

    die("Connection failed: " . mysqli_connect_error());

}

?>








