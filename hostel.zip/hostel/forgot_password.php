<?php
session_start();
require_once 'includes/db.php';

$message = "";

if(isset($_POST['reset'])){

    $email = $_POST['email'];
    $new_password = password_hash(
        $_POST['new_password'],
        PASSWORD_DEFAULT
    );

    $check = mysqli_query($conn,

"SELECT * FROM users
    WHERE email='$email'");

    if(mysqli_num_rows($check) > 0){

        mysqli_query($conn,

"UPDATE users
        SET password='$new_password'
        WHERE email='$email'");

        $message = "Password reset successful.";

    }else{

        $message = "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Forgot Password</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#0f172a;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

.container{
    width:100%;
    max-width:400px;
    background:white;
    padding:35px;
    border-radius:15px;
}

h2{
    text-align:center;
    margin-bottom:20px;
    color:#007bff;
}

.message{
    text-align:center;
    margin-bottom:15px;
    color:green;
}

input{
    width:100%;
    padding:14px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:8px;
}

button{
    width:100%;
    padding:14px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.back{
    margin-top:15px;
    text-align:center;
}

.back a{
    text-decoration:none;
    color:#007bff;
}

</style>

</head>

<body>

<div class="container">

<h2>Reset Password</h2>

<p class="message">

<?php echo $message; ?>

</p>

<form method="POST">

<input type="email"
name="email"
placeholder="Enter Your Email"
required>

<input type="password"
name="new_password"
placeholder="Enter New Password"
required>

<button type="submit"
name="reset">

Reset Password

</button>

</form>

<div class="back">

<a href="login.php">
Back to Login
</a>

</div>

</div>

</body>
</html>
