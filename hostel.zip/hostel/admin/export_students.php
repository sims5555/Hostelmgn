﻿<?php

require_once '../includes/db.php';

// FILE NAME
$filename = "students.csv";

// HEADERS
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="'.$filename.'"');

// OUTPUT
$output = fopen("php://output", "w");

// COLUMN HEADERS
fputcsv($output,

array(
'ID',
'Full Name',
'Email',
'Role'
));

// FETCH STUDENTS
$query = mysqli_query($conn,

"SELECT * FROM users
WHERE role='student'");

while($row = mysqli_fetch_assoc($query)){

    fputcsv($output,

    array(
        $row['id'],
        $row['fullname'],
        $row['email'],
        $row['role']
    ));
}

fclose($output);

exit;
?>
