﻿<?php
session_start();
require_once '../includes/db.php';

// ADD ANNOUNCEMENT
if(isset($_POST['post'])){

    $title = $_POST['title'];
    $message = $_POST['message'];

    mysqli_query($conn,

"INSERT INTO announcements
    (title, message)

    VALUES
    ('$title','$message')");
}

// FETCH ANNOUNCEMENTS
$query = mysqli_query($conn,

"SELECT * FROM announcements
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Announcements</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

input,
textarea{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

textarea{
    height:120px;
    resize:none;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
}

.announcement{
    background:#f8fafc;
    padding:20px;
    margin-top:20px;
    border-left:5px solid #007bff;
    border-radius:5px;
}

.time{
    color:gray;
    margin-top:10px;
    font-size:13px;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Announcements</h2>

<!-- POST ANNOUNCEMENT -->

<form method="POST">

<input type="text"
name="title"
placeholder="Announcement Title"
required>

<textarea
name="message"
placeholder="Announcement Message"
required></textarea>

<button type="submit"
name="post">

Post Announcement

</button>

</form>

<!-- ANNOUNCEMENTS -->

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<div class="announcement">

<h3>

<?php echo $row['title']; ?>

</h3>

<p>

<?php echo $row['message']; ?>

</p>

<div class="time">

<?php echo $row['created_at']; ?>

</div>

</div>

<?php } ?>

</div>

</body>
</html>
