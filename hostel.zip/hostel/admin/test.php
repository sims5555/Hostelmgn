﻿<?php
echo "found real folder";
?>