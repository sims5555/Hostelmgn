﻿<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
<title>Porter Dashboard</title>
</head>
<body>

<h1>PORTER DASHBOARD</h1>
<p>Manage hostel movement and luggage records.</p>
<a href="../security_varify.php">security varify</a>
<div>
<a href="../porter_logs.php">checking/out</a>
<div>
<a href="../student_card.php">hostel pass</a>
<div>
<a href="../../logout.php">Logout</a>


</body>
</html>
