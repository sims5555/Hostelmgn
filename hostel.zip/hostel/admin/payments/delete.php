﻿<?php
require_once '../../includes/db.php';

$id = $_GET['id'];

mysqli_query($conn, "
DELETE FROM payments 
WHERE id='$id'
");

header("Location: index.php");
exit();
?>