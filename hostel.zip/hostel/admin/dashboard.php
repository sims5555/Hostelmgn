﻿<?php
session_start();
include("../config.php");

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

$students = mysqli_query($conn, "SELECT * FROM students");
$rooms = mysqli_query($conn, "SELECT * FROM rooms WHERE status='available'");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #ecf0f1;
}

.header {
    background: #34495e;
    color: white;
    padding: 20px;
    text-align: center;
}

.container {
    padding: 30px;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

select, button {
    padding: 8px;
    width: 100%;
    margin: 10px 0;
}

button {
    background: #27ae60;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
}

button:hover {
    background: #219150;
}

.logout {
    margin-top: 20px;
    display: inline-block;
    color: red;
}
</style>
</head>

<body>

<div class="header">
<h1>Admin Dashboard</h1>
<p>Welcome <?php echo $_SESSION['admin']; ?></p>
</div>

<div class="container">
<div class="card">
<h3>Allocate Room</h3>

<form method="POST" action="allocate.php">
<label>Select Student</label>
<select name="student" required>
<?php while($s = mysqli_fetch_assoc($students)) { ?>
<option value="<?php echo $s['email']; ?>">
<?php echo $s['fullname']; ?> (<?php echo $s['email']; ?>)
</option>
<?php } ?>
</select>

<label>Select Room</label>
<select name="room" required>
<?php while($r = mysqli_fetch_assoc($rooms)) { ?>
<option value="<?php echo $r['room_number']; ?>">
<?php echo $r['room_number']; ?>
</option>
<?php } ?>
</select>

<button type="submit">Allocate Room</button>
</form>
</div>

<a href="../logout.php" class="logout">🚪 Logout</a>
</div>

</body>
</html>
