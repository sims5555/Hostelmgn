﻿<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['admin_role'];

// SUPER ADMIN
if ($role == 'super_admin') {
    header("Location: super_admin/index.php");
    exit();
}

// NORMAL ADMIN
if ($role == 'admin') {
    header("Location: admin_panel/index.php");
    exit();
}

// PORTER
if ($role == 'porter') {
    header("Location: porter/index.php");
    exit();
}

// SECURITY
if ($role == 'security') {
    header("Location: security/index.php");
    exit();
}
<a href="manage_complaints.php" class="card">
   manage complaaints
</a>

<a href="../manage_visitors.php">Manage Visitors</a>


?>
