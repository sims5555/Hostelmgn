﻿<?php
session_start();
require_once '../includes/db.php';

$success = "";
$error = "";

// ALLOCATE STUDENT
if(isset($_POST['allocate'])){

    $student_id = $_POST['student_id'];
    $room_id = $_POST['room_id'];

    // CHECK ROOM
    $check_room = mysqli_query($conn,
"SELECT * FROM rooms WHERE id='$room_id'");

    $room = mysqli_fetch_assoc($check_room);

    // CHECK IF ROOM IS FULL
    if($room['occupied'] >= $room['capacity']){

        $error = "Room is already full.";

    } else {

        // CHECK IF STUDENT ALREADY ALLOCATED
        $check_student = mysqli_query($conn,
"SELECT * FROM allocations
         WHERE student_id='$student_id'");

        if(mysqli_num_rows($check_student) > 0){

            $error = "Student already has a room.";

        } else {

            // SAVE ALLOCATION
            mysqli_query($conn,
"INSERT INTO allocations(student_id, room_id)
             VALUES('$student_id','$room_id')");

            // UPDATE ROOM OCCUPIED
            mysqli_query($conn,
"UPDATE rooms
             SET occupied = occupied + 1
             WHERE id='$room_id'");

            $success = "Room allocated successfully.";
        }
    }
}

// FETCH STUDENTS
$students = mysqli_query($conn,
"SELECT * FROM students");

// FETCH ROOMS
$rooms = mysqli_query($conn,
"SELECT rooms.*, hostels.hostel_name
FROM rooms
JOIN hostels
ON rooms.hostel_id = hostels.id");
?>

<!DOCTYPE html>
<html>
<head>
<title>Allocate Room</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:30px;
}

.card{
    background:white;
    width:500px;
    padding:25px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
}

select{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 20px;
    background:#2c3e50;
    color:white;
    border:none;
}

.success{
    color:green;
    margin-bottom:15px;
}

.error{
    color:red;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="card">

<h2>Allocate Student Room</h2>

<?php if($success != ""){ ?>
<p class="success"><?php echo $success; ?></p>
<?php } ?>

<?php if($error != ""){ ?>
<p class="error"><?php echo $error; ?></p>
<?php } ?>

<form method="POST">

<select name="student_id" required>

<option value="">Select Student</option>

<?php while($student = mysqli_fetch_assoc($students)){ ?>

<option value="<?php echo $student['id']; ?>">

<?php echo $student['fullname']; ?>

</option>

<?php } ?>

</select>

<select name="room_id" required>

<option value="">Select Room</option>

<?php while($room = mysqli_fetch_assoc($rooms)){ ?>

<option value="<?php echo $room['id']; ?>">

<?php echo $room['hostel_name']; ?>

- Room <?php echo $room['room_number']; ?>

(<?php echo $room['occupied']; ?>/<?php echo $room['capacity']; ?>)

</option>

<?php } ?>

</select>

<button type="submit" name="allocate">
Allocate Room
</button>

</form>

</div>

</body>
</html>
