﻿<?php
session_start();
include("../config.php");

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

$student_email = $_POST['student'];
$room_number = $_POST['room'];

// Assign room to student
mysqli_query($conn,
"UPDATE students 
     SET room_number='$room_number'
     WHERE email='$student_email'"
);

// Mark room as occupied
mysqli_query($conn,
"UPDATE rooms 
     SET status='occupied'
     WHERE room_number='$room_number'"
);

header("Location: dashboard.php");
exit();
O