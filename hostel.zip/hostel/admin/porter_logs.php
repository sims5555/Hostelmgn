﻿<?php
require_once '../includes/db.php';

$message = "";

if(isset($_POST['submit'])){

    $matric_no = $_POST['matric_no'];
    $movement_type = $_POST['movement_type'];

    // FIND STUDENT
    $student_query = mysqli_query($conn,

"SELECT * FROM students
    WHERE matric_no='$matric_no'");

    if(mysqli_num_rows($student_query) > 0){

        $student = mysqli_fetch_assoc($student_query);

        $student_id = $student['id'];

        // SAVE MOVEMENT
        mysqli_query($conn,

"INSERT INTO movement_logs
        (student_id, movement_type)

        VALUES
        ('$student_id','$movement_type')");

        $message = "Movement recorded successfully.";

    } else {

        $message = "Student not found.";
    }
}

// FETCH LOGS
$logs = mysqli_query($conn,

"SELECT movement_logs.*,
students.fullname,
students.matric_no

FROM movement_logs

JOIN students
ON movement_logs.student_id = students.id

ORDER BY movement_logs.id DESC");

?>

<!DOCTYPE html>
<html>
<head>
<title>Porter Movement Logs</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:30px;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
    margin-bottom:20px;
}

input, select{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 20px;
    background:#2c3e50;
    color:white;
    border:none;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2c3e50;
    color:white;
    padding:12px;
}

table td{
    padding:10px;
    border-bottom:1px solid #ddd;
}

</style>

</head>

<body>

<div class="card">

<h2>Porter Check-In / Check-Out</h2>

<p><?php echo $message; ?></p>

<form method="POST">

<input type="text"
name="matric_no"
placeholder="Enter Matric Number"
required>

<select name="movement_type" required>

<option value="">Select Movement</option>

<option value="CHECK-IN">
CHECK-IN
</option>

<option value="CHECK-OUT">
CHECK-OUT
</option>

</select>

<button type="submit" name="submit">
Save Movement
</button>

</form>

</div>

<div class="card">

<h2>Movement Logs</h2>

<table>

<tr>

<th>ID</th>
<th>Student</th>
<th>Matric No</th>
<th>Movement</th>
<th>Time</th>

</tr>

<?php while($log = mysqli_fetch_assoc($logs)){ ?>

<tr>

<td><?php echo $log['id']; ?></td>

<td><?php echo $log['fullname']; ?></td>

<td><?php echo $log['matric_no']; ?></td>

<td><?php echo $log['movement_type']; ?></td>

<td><?php echo $log['movement_time']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
