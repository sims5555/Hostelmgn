﻿<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
<title>Security Dashboard</title>
</head>
<body>

<h1>SECURITY DASHBOARD</h1>
<p>Manage gate access and student verification.</p>
<a href="../../security_varify.php">security varify</a>
<a href="../manage_visitors.php">vissitors management</a>
<a href="../../logout.php">Logout</a>

</body>
</html>
`