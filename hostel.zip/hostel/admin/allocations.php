﻿<?php
session_start();
require_once '../includes/db.php';

// FETCH ALLOCATIONS
$query = mysqli_query($conn,

"SELECT allocations.*,
students.fullname,
rooms.room_number,
hostels.hostel_name

FROM allocations

JOIN students
ON allocations.student_id = students.id

JOIN rooms
ON allocations.room_id = rooms.id

JOIN hostels
ON rooms.hostel_id = hostels.id

ORDER BY allocations.id DESC
");

?>

<!DOCTYPE html>
<html>
<head>
<title>Room Allocations</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:20px;
}

.container{
    width:95%;
    margin:auto;
}

.card{
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2c3e50;
    color:white;
    padding:12px;
}

table td{
    padding:10px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f1f1f1;
}

.btn{
    padding:7px 10px;
    background:red;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<h2>All Room Allocations</h2>

<table>

<tr>

<th>ID</th>
<th>Student</th>
<th>Hostel</th>
<th>Room</th>
<th>Allocated Date</th>
<th>card<th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['fullname']; ?></td>

<td><?php echo $row['hostel_name']; ?></td>

<td><?php echo $row['room_number']; ?></td>

<td><?php echo $row['allocated_at']; ?></td>

<td>

<td>

<a class="btn"
style="background:green;"
href="student_card.php?id=<?php echo $row['student_id']; ?>">

View Card

</a>

</td>

<td>

<a class="btn"
href="remove_allocation.php?id=<?php echo $row['id']; ?>">

Remove

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>
</html>