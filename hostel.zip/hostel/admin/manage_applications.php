﻿<?php
session_start();
require_once '../includes/db.php';

// APPROVE & ALLOCATE
if(isset($_GET['approve'])){

    $id = $_GET['approve'];

    // GET APPLICATION
    $app_query = mysqli_query($conn,

"SELECT * FROM hostel_applications
    WHERE id='$id'");

    $application = mysqli_fetch_assoc($app_query);

    if($application){

        $student_id = $application['student_id'];
        $hostel_name = $application['hostel_name'];

        // FIND AVAILABLE ROOM
        $room_query = mysqli_query($conn,

"SELECT * FROM rooms
        WHERE occupied < capacity
        LIMIT 1");

        if(mysqli_num_rows($room_query) > 0){

            $room = mysqli_fetch_assoc($room_query);

            $room_id = $room['id'];

            // SAVE ALLOCATION
            mysqli_query($conn,

"INSERT INTO allocations
            (student_id, room_id, hostel_name)

            VALUES
            ('$student_id','$room_id','$hostel_name')");

            // UPDATE ROOM OCCUPIED
            mysqli_query($conn,

"UPDATE rooms
            SET occupied = occupied + 1
            WHERE id='$room_id'");

            // UPDATE APPLICATION
            mysqli_query($conn,

"UPDATE hostel_applications
            SET status='Approved'
            WHERE id='$id'");

            // NOTIFICATION
            $message = "Your hostel application has been approved and room allocated successfully.";

            mysqli_query($conn,

"INSERT INTO notifications
            (student_id, message, status)

            VALUES
            ('$student_id',
'$message',
'unread')");
        }
    }
}

// REJECT APPLICATION
if(isset($_GET['reject'])){

    $id = $_GET['reject'];

    mysqli_query($conn,

"UPDATE hostel_applications
    SET status='Rejected'
    WHERE id='$id'");
}

// SEARCH
$search = "";

if(isset($_GET['search'])){
    $search = $_GET['search'];
}

// FETCH APPLICATIONS
$query = mysqli_query($conn,

"SELECT * FROM hostel_applications

WHERE student_id LIKE '%$search%'
OR hostel_name LIKE '%$search%'

ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Applications</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

.search-box{
    margin-bottom:20px;
}

.search-box input{
    width:300px;
    padding:12px;
}

.search-box button{
    padding:12px 16px;
    background:#007bff;
    color:white;
    border:none;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

.btn{
    padding:8px 14px;
    text-decoration:none;
    color:white;
    border-radius:5px;
}

.approve{
    background:green;
}

.reject{
    background:red;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Applications</h2>

<!-- SEARCH -->

<form class="search-box" method="GET">

<input type="text"
name="search"
placeholder="Search applications..."
value="<?php echo $search; ?>">

<button type="submit">
Search
</button>

</form>

<table>

<tr>

<th>ID</th>
<th>Student ID</th>
<th>Hostel</th>
<th>Room Type</th>
<th>Status</th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['student_id']; ?></td>

<td><?php echo $row['hostel_name']; ?></td>

<td><?php echo $row['room_type']; ?></td>

<td><?php echo $row['status']; ?></td>

<td>

<a class="btn approve"
href="?approve=<?php echo $row['id']; ?>">

Approve & Allocate

</a>

<a class="btn reject"
href="?reject=<?php echo $row['id']; ?>">

Reject

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
