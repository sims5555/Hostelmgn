﻿<?php
session_start();
require_once '../includes/db.php';

// TOTAL STUDENTS
$students = mysqli_query($conn,

"SELECT COUNT(*) AS total_students
FROM users
WHERE role='student'");

$student_data = mysqli_fetch_assoc($students);

// TOTAL PAYMENTS
$payments = mysqli_query($conn,

"SELECT SUM(amount) AS total_payments
FROM payments");

$payment_data = mysqli_fetch_assoc($payments);

// TOTAL COMPLAINTS
$complaints = mysqli_query($conn,

"SELECT COUNT(*) AS total_complaints
FROM complaints");

$complaint_data = mysqli_fetch_assoc($complaints);

// TOTAL VISITORS
$visitors = mysqli_query($conn,

"SELECT COUNT(*) AS total_visitors
FROM visitors");

$visitor_data = mysqli_fetch_assoc($visitors);

// TOTAL ROOMS
$rooms = mysqli_query($conn,

"SELECT COUNT(*) AS total_rooms
FROM rooms");

$room_data = mysqli_fetch_assoc($rooms);

// TOTAL ALLOCATIONS
$allocations = mysqli_query($conn,

"SELECT COUNT(*) AS total_allocations
FROM allocations");

$allocation_data = mysqli_fetch_assoc($allocations);

?>

<!DOCTYPE html>
<html>

<head>

<title>System Reports</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

h1{
    color:#1e293b;
}

.print-btn{
    background:#007bff;
    color:white;
    border:none;
    padding:12px 18px;
    cursor:pointer;
    border-radius:5px;
}

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

.card h2{
    font-size:18px;
    margin-bottom:10px;
    color:#64748b;
}

.card h1{
    color:#007bff;
    margin:0;
}

/* PRINT MODE */

@media print{

    .print-btn{
        display:none;
    }

    body{
        background:white;
    }

    .card{
        box-shadow:none;
        border:1px solid #ddd;
    }
}

</style>

</head>

<body>

<div class="header">

<h1>System Reports Dashboard</h1>

<button class="print-btn"
onclick="window.print()">

Print Report

</button>

</div>

<div class="grid">

<div class="card">

<h2>Total Students</h2>

<h1>

<?php echo $student_data['total_students']; ?>

</h1>

</div>

<div class="card">

<h2>Total Payments</h2>

<h1>

₦<?php echo number_format($payment_data['total_payments']); ?>

</h1>

</div>

<div class="card">

<h2>Total Complaints</h2>

<h1>

<?php echo $complaint_data['total_complaints']; ?>

</h1>

</div>

<div class="card">

<h2>Total Visitors</h2>

<h1>

<?php echo $visitor_data['total_visitors']; ?>

</h1>

</div>

<div class="card">

<h2>Total Rooms</h2>

<h1>

<?php echo $room_data['total_rooms']; ?>

</h1>

</div>

<div class="card">

<h2>Total Allocations</h2>

<h1>

<?php echo $allocation_data['total_allocations']; ?>

</h1>

</div>

</div>

</body>
</html>
