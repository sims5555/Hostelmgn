﻿<?php
session_start();
require_once '../includes/db.php';

// FETCH LOGS
$query = mysqli_query($conn,

"SELECT * FROM activity_logs
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Activity Logs</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

</style>

</head>

<body>

<div class="container">

<h2>System Activity Logs</h2>

<table>

<tr>

<th>ID</th>
<th>User ID</th>
<th>Activity</th>
<th>Date</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php echo $row['user_id']; ?>

</td>

<td>

<?php echo $row['activity']; ?>

</td>

<td>

<?php echo $row['created_at']; ?>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
