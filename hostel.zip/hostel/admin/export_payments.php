﻿<?php

require_once '../includes/db.php';

// FILE NAME
$filename = "payments.csv";

// HEADERS
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="'.$filename.'"');

// OUTPUT
$output = fopen("php://output", "w");

// COLUMN HEADERS
fputcsv($output,

array(
'Student ID',
'Total Paid',
'Payment Status'
));

// HOSTEL FEE
$hostel_fee = 50000;

// FETCH PAYMENTS
$query = mysqli_query($conn,

"SELECT student_id,
SUM(amount) AS total_paid

FROM payments

GROUP BY student_id

ORDER BY student_id DESC");

while($row = mysqli_fetch_assoc($query)){

    $balance = $hostel_fee - $row['total_paid'];

    $status = ($balance <= 0)
    ? 'Fully Paid'
    : 'Pending';

    fputcsv($output,

    array(
        $row['student_id'],
        $row['total_paid'],
        $status
    ));
}

fclose($output);

exit;
?>
