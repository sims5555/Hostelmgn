﻿<?php
session_start();
require_once '../includes/db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = mysqli_query($conn,
"SELECT * FROM admins
     WHERE email='$email'
     AND password='$password'");

    if (mysqli_num_rows($query) > 0) {

        $admin = mysqli_fetch_assoc($query);

        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_role'] = $admin['role'];

        header("Location: index.php");
        exit();

    } else {

        $message = "Invalid Login";

    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
}

.login-box{
    width:350px;
    margin:100px auto;
    background:white;
    padding:30px;
    border-radius:10px;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    width:100%;
    padding:12px;
    background:#2c3e50;
    color:white;
    border:none;
}

.error{
    color:red;
}
</style>
</head>

<body>

<div class="login-box">

<h2>Admin Login</h2>

<?php if($message != ""){ ?>
<p class="error"><?php echo $message; ?></p>
<?php } ?>

<form method="POST">

<input type="email"
       name="email"
       placeholder="Enter Email"
       required>

<input type="password"
       name="password"
       placeholder="Enter Password"
       required>

<button type="submit">
Login
</button>

</form>

</div>

</body>
</html>
