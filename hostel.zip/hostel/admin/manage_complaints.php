<?php
session_start();
require_once '../includes/db.php';

// RESOLVE COMPLAINT
if(isset($_GET['resolve'])){

    $id = $_GET['resolve'];

    // GET COMPLAINT
    $complaint_query = mysqli_query($conn,

"SELECT * FROM complaints
    WHERE id='$id'");

    $complaint = mysqli_fetch_assoc($complaint_query);

    if($complaint){

        $student_id = $complaint['student_id'];

        // UPDATE STATUS
        mysqli_query($conn,

"UPDATE complaints
        SET status='Resolved'
        WHERE id='$id'");

        // NOTIFICATION
        $message = "Your complaint has been resolved successfully.";

        mysqli_query($conn,

"INSERT INTO notifications
        (student_id, message, status)

        VALUES
        ('$student_id',
'$message',
'unread')");

        // ACTIVITY LOG
        $activity = "Resolved a complaint";

        mysqli_query($conn,

"INSERT INTO activity_logs
        (user_id, activity)

        VALUES
        ('$student_id','$activity')");
    }
}

// SEARCH
$search = "";

if(isset($_GET['search'])){
    $search = $_GET['search'];
}

// FETCH COMPLAINTS
$query = mysqli_query($conn,

"SELECT * FROM complaints

WHERE student_id LIKE '%$search%'
OR complaint_type LIKE '%$search%'

ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Complaints</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

/* TOP BAR */

.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    margin-bottom:20px;
}

.top-bar h2{
    color:#1e293b;
}

/* EXPORT */

.export-btn{
    background:green;
    color:white;
    padding:10px 15px;
    text-decoration:none;
    border-radius:5px;
}

/* SEARCH */

.search-box{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
    margin-bottom:20px;
}

.search-box input{
    width:300px;
    padding:12px;
    border:1px solid #ccc;
    border-radius:5px;
}

.search-box button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* TABLE */

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
    text-align:left;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

/* BUTTON */

.resolve-btn{
    background:#007bff;
    color:white;
    padding:8px 14px;
    text-decoration:none;
    border-radius:5px;
}

/* STATUS */

.pending{
    color:orange;
    font-weight:bold;
}

.resolved{
    color:green;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<!-- TOP BAR -->

<div class="top-bar">

<h2>Manage Complaints</h2>

<a href="export_complaints.php"
class="export-btn">

Export Complaints

</a>

</div>

<!-- SEARCH -->

<form class="search-box" method="GET">

<input type="text"
name="search"
placeholder="Search complaints..."
value="<?php echo $search; ?>">

<button type="submit">

Search

</button>

</form>

<!-- TABLE -->

<table>

<tr>

<th>ID</th>
<th>Student ID</th>
<th>Complaint Type</th>
<th>Description</th>
<th>Status</th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['student_id']; ?></td>

<td><?php echo $row['complaint_type']; ?></td>

<td><?php echo $row['description']; ?></td>

<td>

<?php

if($row['status'] == 'Resolved'){

    echo "<span class='resolved'>
    Resolved
</span>";

}else{

    echo "<span class='pending'>
    Pending
</span>";
}

?>

</td>

<td>

<a class="resolve-btn"

href="?resolve=<?php echo $row['id']; ?>">

Resolve

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
