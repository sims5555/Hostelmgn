﻿<?php
session_start();
require_once '../includes/db.php';

// APPROVE VISITOR
if(isset($_GET['approve'])){

    $id = $_GET['approve'];

    // GET VISITOR
    $visitor_query = mysqli_query($conn,

"SELECT * FROM visitors
    WHERE id='$id'");

    if(mysqli_num_rows($visitor_query) > 0){

        $visitor = mysqli_fetch_assoc($visitor_query);

        $student_id = $visitor['student_id'];

        // UPDATE STATUS
        mysqli_query($conn,

"UPDATE visitors
        SET status='Approved',
        time_in=NOW()
        WHERE id='$id'");

        // SEND NOTIFICATION
        $message = "Your visitor request has been approved.";

        mysqli_query($conn,

"INSERT INTO notifications
        (student_id, message, status)

        VALUES
        ('$student_id',
'$message',
'unread')");
    }
}

// CHECK OUT VISITOR
if(isset($_GET['checkout'])){

    $id = $_GET['checkout'];

    mysqli_query($conn,

"UPDATE visitors
    SET status='Checked Out',
    time_out=NOW()
    WHERE id='$id'");
}

// SEARCH
$search = "";

if(isset($_GET['search'])){
    $search = $_GET['search'];
}

// FETCH VISITORS
$query = mysqli_query($conn,

"SELECT * FROM visitors

WHERE student_id LIKE '%$search%'
OR visitor_name LIKE '%$search%'

ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Visitors</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

.search-box{
    margin-bottom:20px;
}

.search-box input{
    width:300px;
    padding:12px;
}

.search-box button{
    padding:12px 16px;
    background:#007bff;
    color:white;
    border:none;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:14px;
}

table td{
    padding:14px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

.btn{
    padding:8px 14px;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

.approve{
    background:green;
}

.checkout{
    background:red;
}

.pending{
    color:orange;
    font-weight:bold;
}

.approved{
    color:green;
    font-weight:bold;
}

.checked{
    color:red;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Visitors</h2>

<!-- SEARCH -->

<form class="search-box" method="GET">

<input type="text"
name="search"
placeholder="Search visitors..."
value="<?php echo $search; ?>">

<button type="submit">
Search
</button>

</form>

<table>

<tr>

<th>ID</th>
<th>Student ID</th>
<th>Visitor Name</th>
<th>Phone</th>
<th>Visit Date</th>
<th>Status</th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['student_id']; ?></td>

<td><?php echo $row['visitor_name']; ?></td>

<td><?php echo $row['phone']; ?></td>

<td><?php echo $row['visit_date']; ?></td>

<td>

<?php

if($row['status'] == 'Approved'){

    echo "<span class='approved'>
    Approved
</span>";

}elseif($row['status'] == 'Checked Out'){

    echo "<span class='checked'>
    Checked Out
</span>";

}else{

    echo "<span class='pending'>
    Pending
</span>";
}

?>

</td>

<td>

<?php if($row['status'] == 'Pending'){ ?>

<a class="btn approve"
href="?approve=<?php echo $row['id']; ?>">

Approve

</a>

<?php } ?>

<?php if($row['status'] == 'Approved'){ ?>

<a class="btn checkout"
href="?checkout=<?php echo $row['id']; ?>">

Check Out

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
