﻿<?php
require_once '../includes/db.php';

$id = $_GET['id'];

// GET ROOM ID
$get = mysqli_query($conn,
"SELECT * FROM allocations WHERE id='$id'");

$data = mysqli_fetch_assoc($get);

$room_id = $data['room_id'];

// DELETE ALLOCATION
mysqli_query($conn,
"DELETE FROM allocations WHERE id='$id'");

// REDUCE OCCUPIED
mysqli_query($conn,
"UPDATE rooms
SET occupied = occupied - 1
WHERE id='$room_id'");

header("Location: allocations.php");
exit();
?>
