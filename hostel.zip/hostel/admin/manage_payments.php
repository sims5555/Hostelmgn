﻿<?php
session_start();
require_once '../includes/db.php';

// HOSTEL FEE
$hostel_fee = 50000;

// ADD PAYMENT
if(isset($_POST['add_payment'])){

    $student_id = $_POST['student_id'];
    $amount = $_POST['amount'];

    // INSERT PAYMENT
    mysqli_query($conn,

"INSERT INTO payments
    (student_id, amount)

    VALUES
    ('$student_id','$amount')");

    // SEND NOTIFICATION
    $message = "Your hostel payment of ₦$amount was recorded successfully.";

    mysqli_query($conn,

"INSERT INTO notifications
    (student_id, message, status)

    VALUES
    ('$student_id',
'$message',
'unread')");
}

// FETCH PAYMENTS WITH TOTALS
$query = mysqli_query($conn,

"SELECT student_id,
SUM(amount) AS total_paid

FROM payments

GROUP BY student_id

ORDER BY student_id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Payments</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

.fee-box{
    background:#007bff;
    color:white;
    padding:15px;
    border-radius:8px;
    margin-bottom:20px;
    font-size:18px;
}

form{
    margin-bottom:30px;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

.paid{
    color:green;
    font-weight:bold;
}

.balance{
    color:red;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Payments</h2>

<div class="fee-box">

Hostel Fee:
<strong>

₦<?php echo number_format($hostel_fee); ?>

</strong>

</div>

<!-- PAYMENT FORM -->

<form method="POST">

<input type="number"
name="student_id"
placeholder="Student ID"
required>

<input type="number"
name="amount"
placeholder="Payment Amount"
required>

<button type="submit"
name="add_payment">

Record Payment

</button>

</form>

<!-- PAYMENT TABLE -->

<table>

<tr>

<th>Student ID</th>
<th>Total Paid</th>
<th>Balance</th>
<th>Status</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<?php

$total_paid = $row['total_paid'];

$balance = $hostel_fee - $total_paid;

?>

<tr>

<td>

<?php echo $row['student_id']; ?>

</td>

<td class="paid">

₦<?php echo number_format($total_paid); ?>

</td>

<td class="balance">

₦<?php echo number_format($balance); ?>

</td>

<td>

<?php

if($balance <= 0){

    echo "<span class='paid'>
    Fully Paid
</span>";

}else{

    echo "<span class='balance'>
    Pending
</span>";
}

?>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
