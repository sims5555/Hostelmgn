﻿<?php
require_once '../includes/db.php';

$id = $_GET['id'];

// FETCH STUDENT DETAILS
$query = mysqli_query($conn,

"SELECT students.*,
rooms.room_number,
hostels.hostel_name,
payments.status AS payment_status

FROM allocations

JOIN students
ON allocations.student_id = students.id

JOIN rooms
ON allocations.room_id = rooms.id

JOIN hostels
ON rooms.hostel_id = hostels.id

LEFT JOIN payments
ON students.id = payments.student_id

WHERE students.id='$id'
");

$data = mysqli_fetch_assoc($query);

?>

<!DOCTYPE html>
<html>
<head>
<title>Student Hostel Card</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:40px;
}

.card{
    width:450px;
    margin:auto;
    background:white;
    border-radius:10px;
    padding:30px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.header{
    text-align:center;
    margin-bottom:20px;
}

.header h2{
    margin:0;
}

.photo{
    width:120px;
    height:120px;
    border-radius:50%;
    background:#ddd;
    margin:20px auto;
    overflow:hidden;
}

.photo img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.info{
    margin-top:20px;
}

.info p{
    margin:10px 0;
    font-size:16px;
}

.btn{
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:#2c3e50;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="card">

<div class="header">

<h2>GLOBAL WEALTH UNIVERSITY</h2>
<p>Hostel Clearance Card</p>

</div>

<div class="photo">

<img src="../uploads/<?php echo $data['passport']; ?>">

</div>

<div class="info">

<p><strong>Name:</strong>
<?php echo $data['fullname']; ?></p>

<p><strong>Matric No:</strong>
<?php echo $data['matric_no']; ?></p>

<p><strong>Hostel:</strong>
<?php echo $data['hostel_name']; ?></p>

<p><strong>Room:</strong>
<?php echo $data['room_number']; ?></p>

<p><strong>Payment:</strong>
<?php echo $data['payment_status']; ?></p>

</div>

<a class="btn" href="#" onclick="window.print()">
Print Card
</a>

</div>

</body>
</htm
