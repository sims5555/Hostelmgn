﻿ <?php

require_once '../includes/db.php';

// FILE NAME
$filename = "complaints.csv";

// HEADERS
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="'.$filename.'"');

// OUTPUT
$output = fopen("php://output", "w");

// COLUMN HEADERS
fputcsv($output,

array(
'ID',
'Student ID',
'Complaint Type',
'Description',
'Status'
));

// FETCH COMPLAINTS
$query = mysqli_query($conn,

"SELECT * FROM complaints
ORDER BY id DESC");

while($row = mysqli_fetch_assoc($query)){

    fputcsv($output,

    array(
        $row['id'],
        $row['student_id'],
        $row['complaint_type'],
        $row['description'],
        $row['status']
    ));
}

fclose($output);

exit;
?>
