﻿<?php
require_once '../includes/db.php';
$data = null;

if(isset($_POST['search'])){

    $matric_no = $_POST['matric_no'];

    $query = mysqli_query($conn,

"SELECT students.*,
    rooms.room_number,
    hostels.hostel_name,
    payments.status AS payment_status

    FROM allocations

    JOIN students
    ON allocations.student_id = students.id

    JOIN rooms
    ON allocations.room_id = rooms.id

    JOIN hostels
    ON rooms.hostel_id = hostels.id

    LEFT JOIN payments
    ON students.id = payments.student_id

    WHERE students.matric_no='$matric_no'
");

    $data = mysqli_fetch_assoc($query);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Security Verification</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:40px;
}

.container{
    width:500px;
    margin:auto;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 20px;
    background:#2c3e50;
    color:white;
    border:none;
}

.result{
    margin-top:20px;
    padding:20px;
    background:#f9f9f9;
    border-radius:10px;
}

.valid{
    color:green;
    font-weight:bold;
}

.invalid{
    color:red;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<h2>Security Verification</h2>

<form method="POST">

<input type="text"
name="matric_no"
placeholder="Enter Matric Number"
required>

<button type="submit" name="search">
Verify Student
</button>

</form>

<?php if($data){ ?>

<div class="result">

<p class="valid">Student Verified</p>

<p><strong>Name:</strong>
<?php echo $data['fullname']; ?></p>

<p><strong>Matric No:</strong>
<?php echo $data['matric_no']; ?></p>

<p><strong>Hostel:</strong>
<?php echo $data['hostel_name']; ?></p>

<p><strong>Room:</strong>
<?php echo $data['room_number']; ?></p>

<p><strong>Payment:</strong>
<?php echo $data['payment_status']; ?></p>

</div>

<?php } elseif(isset($_POST['search'])){ ?>

<div class="result">

<p class="invalid">
Student Not Found
</p>

</div>

<?php } ?>

</div>

</div>

</body>
</html>
