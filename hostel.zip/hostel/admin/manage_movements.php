﻿<?php
session_start();
require_once '../includes/db.php';

// SECURITY
if(!isset($_SESSION['role'])){
    die("Access Denied");
}

// FETCH MOVEMENT LOGS
$query = mysqli_query($conn,
"SELECT * FROM movement_logs ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Movement Logs</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
    text-align:left;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

.status-in{
    color:green;
    font-weight:bold;
}

.status-out{
    color:red;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<h2>Student Movement Logs</h2>

<table>

<tr>

<th>ID</th>
<th>Student ID</th>
<th>Movement</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td>
<?php echo $row['id']; ?>
</td>

<td>
<?php echo $row['student_id']; ?>
</td>

<td>

<?php

// CHECK DATABASE COLUMN

if(isset($row['movement'])){

    if($row['movement'] == 'IN'){

        echo "<span class='status-in'>
        CHECKED IN
</span>";

    }else{

        echo "<span class='status-out'>
        CHECKED OUT
</span>";
    }

}else{

    echo "<span class='status-out'>
    CHECKED OUT
</span>";
}

?>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
