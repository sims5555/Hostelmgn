﻿<?php
require_once "../../middleware/auth.php";
require_once "../../middleware/role.php";
require_once "../../config.php";

checkRole(['super_admin', 'hostel_admin']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $room_number = $_POST['room_number'];
    $hostel_name = $_POST['hostel_name'];
    $capacity = $_POST['capacity'];

    $stmt = $conn->prepare("INSERT INTO rooms (room_number, hostel_name, capacity) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $room_number, $hostel_name, $capacity);
    $stmt->execute();

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Room</title>
<link rel="stylesheet" href="../../assets/style.css">
</head>
<body>

<div class="container">
<h2>Add New Room</h2>

<form method="POST">
        Room Number:<br>
<input type="text" name="room_number" required><br><br>

        Hostel Name:<br>
<input type="text" name="hostel_name" required><br><br>

        Capacity:<br>
<input type="number" name="capacity" required><br><br>

<button type="submit">Create Room</button>
</form>

<br>
<a href="index.php">⬅ Back</a>
</div>

</body>
</html>
