﻿
<?php
require_once "../../middleware/auth.php";
require_once "../../middleware/role.php";
require_once "../../config.php";

checkRole(['super_admin', 'hostel_admin']);

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM rooms WHERE id=$id");
}

header("Location: index.php");
exit();
