<?php
session_start();
require_once '../../includes/db.php';

// ADD ROOM
if(isset($_POST['add_room'])){

    $hostel_id = $_POST['hostel_id'];
    $room_number = $_POST['room_number'];
    $capacity = $_POST['capacity'];

    mysqli_query($conn,
"INSERT INTO rooms(hostel_id, room_number, capacity)
    VALUES('$hostel_id','$room_number','$capacity')");
}

// FETCH HOSTELS
$hostels = mysqli_query($conn,
"SELECT * FROM hostels");

// FETCH ROOMS
$rooms = mysqli_query($conn,
"SELECT rooms.*, hostels.hostel_name
FROM rooms
JOIN hostels
ON rooms.hostel_id = hostels.id
ORDER BY rooms.id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Room Management</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:20px;
}

.container{
    width:95%;
    margin:auto;
}

.card{
    background:white;
    padding:20px;
    border-radius:10px;
    margin-bottom:20px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

input, select{
    padding:10px;
    margin:10px 0;
    width:100%;
}

button{
    padding:10px 15px;
    background:#2c3e50;
    color:white;
    border:none;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2c3e50;
    color:white;
    padding:12px;
}

table td{
    padding:10px;
    border-bottom:1px solid #ddd;
}

</style>
</head>

<body>

<div class="container">

<div class="card">

<h2>Add Room</h2>

<form method="POST">

<select name="hostel_id" required>

<option value="">Select Hostel</option>

<?php while($hostel = mysqli_fetch_assoc($hostels)){ ?>

<option value="<?php echo $hostel['id']; ?>">
<?php echo $hostel['hostel_name']; ?>
</option>

<?php } ?>

</select>

<input type="text"
       name="room_number"
       placeholder="Room Number"
       required>

<input type="number"
       name="capacity"
       placeholder="Room Capacity"
       required>

<button type="submit" name="add_room">
Add Room
</button>

</form>

</div>

<div class="card">

<h2>All Rooms</h2>

<table>

<tr>
<th>ID</th>
<th>Hostel</th>
<th>Room</th>
<th>Capacity</th>
<th>Occupied</th>
<th>Status</th>
</tr>

<?php while($room = mysqli_fetch_assoc($rooms)){ ?>

<tr>

<td><?php echo $room['id']; ?></td>

<td><?php echo $room['hostel_name']; ?></td>

<td><?php echo $room['room_number']; ?></td>

<td><?php echo $room['capacity']; ?></td>

<td><?php echo $room['occupied']; ?></td>

<td><?php echo $room['status']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>
</html>
