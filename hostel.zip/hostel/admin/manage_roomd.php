﻿<?php
session_start();
require_once '../includes/db.php';

// ADD ROOM
if(isset($_POST['add_room'])){

    $room_number = $_POST['room_number'];
    $capacity = $_POST['capacity'];
    $hostel_name = $_POST['hostel_name'];

    mysqli_query($conn,

"INSERT INTO rooms
    (room_number, capacity, occupied, hostel_name)

    VALUES
    ('$room_number',
'$capacity',
    0,
'$hostel_name')");
}

// FETCH ROOMS
$query = mysqli_query($conn,

"SELECT * FROM rooms
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Rooms</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

form{
    margin-bottom:30px;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

.available{
    color:green;
    font-weight:bold;
}

.full{
    color:red;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Rooms</h2>

<!-- ADD ROOM -->

<form method="POST">

<input type="text"
name="hostel_name"
placeholder="Hostel Name"
required>

<input type="text"
name="room_number"
placeholder="Room Number"
required>

<input type="number"
name="capacity"
placeholder="Room Capacity"
required>

<button type="submit"
name="add_room">

Add Room

</button>

</form>

<!-- ROOM TABLE -->

<table>

<tr>

<th>ID</th>
<th>Hostel</th>
<th>Room Number</th>
<th>Capacity</th>
<th>Occupied</th>
<th>Status</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['hostel_name']; ?></td>

<td><?php echo $row['room_number']; ?></td>

<td><?php echo $row['capacity']; ?></td>

<td><?php echo $row['occupied']; ?></td>

<td>

<?php

if($row['occupied'] < $row['capacity']){

    echo "<span class='available'>
    Available
</span>";

}else{

    echo "<span class='full'>
    Full
</span>";
}

?>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
