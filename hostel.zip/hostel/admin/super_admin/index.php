﻿<?php
session_start();
require_once '../../includes/db.php';

// TOTAL ADMINS
$admins = mysqli_query($conn,

"SELECT COUNT(*) AS total_admins
FROM users
WHERE role='admin'");

$admin_data = mysqli_fetch_assoc($admins);

// TOTAL STUDENTS
$students = mysqli_query($conn,

"SELECT COUNT(*) AS total_students
FROM users
WHERE role='student'");

$student_data = mysqli_fetch_assoc($students);

// TOTAL PAYMENTS
$payments = mysqli_query($conn,

"SELECT SUM(amount) AS total_payments
FROM payments");

$payment_data = mysqli_fetch_assoc($payments);

// TOTAL COMPLAINTS
$complaints = mysqli_query($conn,

"SELECT COUNT(*) AS total_complaints
FROM complaints");

$complaint_data = mysqli_fetch_assoc($complaints);

// TOTAL VISITORS
$visitors = mysqli_query($conn,

"SELECT COUNT(*) AS total_visitors
FROM visitors");

$visitor_data = mysqli_fetch_assoc($visitors);

// TOTAL ROOMS
$rooms = mysqli_query($conn,

"SELECT COUNT(*) AS total_rooms
FROM rooms");

$room_data = mysqli_fetch_assoc($rooms);

?>

<!DOCTYPE html>
<html>

<head>

<title>Super Admin Dashboard</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    display:flex;
    font-family:Arial;
    background:#f1f5f9;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:#0f172a;
    min-height:100vh;
    padding:20px;
}

.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    padding:12px;
    margin-bottom:10px;
    background:#1e293b;
    border-radius:5px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#007bff;
}

/* CONTENT */

.content{
    flex:1;
    padding:30px;
}

.content h1{
    margin-bottom:30px;
    color:#1e293b;
}

/* CARDS */

.cards{
    display:grid;
    grid-template-columns:
    repeat(auto-fit,minmax(220px,1fr));

    gap:20px;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

.card h3{
    color:#64748b;
    margin-bottom:10px;
}

.card h1{
    color:#007bff;
    margin:0;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<h2>SUPER ADMIN</h2>

<a href="index.php">
Dashboard
</a>

<a href="manage_admins.php">
Manage Admins
</a>

<a href="../manage_students.php">
Manage Students
</a>

<a href="../manage_applications.php">
Manage Applications
</a>

<a href="../manage_rooms.php">
Manage Rooms
</a>

<a href="../manage_complaints.php">
Manage Complaints
</a>

<a href="../manage_visitors.php">
Manage Visitors
</a>

<a href="../payments/index.php">
Payments
</a>

<a href="../reports.php">
Reports
</a>

<a href="../announcements.php">
Announcements
</a>

<a href="../activity_logs.php">
Activity Logs
</a>

<a href="../settings.php">
system settings
</a>


<a href="../../logout.php">
Logout
</a>

</div>

<!-- CONTENT -->

<div class="content">

<h1>Super Admin Dashboard</h1>

<div class="cards">

<div class="card">

<h3>Total Admins</h3>

<h1>

<?php echo $admin_data['total_admins']; ?>

</h1>

</div>

<div class="card">

<h3>Total Students</h3>

<h1>

<?php echo $student_data['total_students']; ?>

</h1>

</div>

<div class="card">

<h3>Total Payments</h3>

<h1>

₦<?php echo number_format($payment_data['total_payments']); ?>

</h1>

</div>

<div class="card">

<h3>Total Complaints</h3>

<h1>

<?php echo $complaint_data['total_complaints']; ?>

</h1>

</div>

<div class="card">

<h3>Total Visitors</h3>

<h1>

<?php echo $visitor_data['total_visitors']; ?>

</h1>

</div>

<div class="card">

<h3>Total Rooms</h3>

<h1>

<?php echo $room_data['total_rooms']; ?>

</h1>

</div>
<!-- QUICK ACTIONS -->

<h1 style="
margin-top:40px;
margin-bottom:20px;
color:#1e293b;
">

Quick Actions

</h1>

<div class="cards">

<a href="../manage_students.php"

style="
text-decoration:none;
">

<div class="card">

<h3>Manage Students</h3>

<p>
View and manage students
</p>

</div>

</a>

<a href="../manage_rooms.php"

style="
text-decoration:none;
">

<div class="card">

<h3>Manage Rooms</h3>

<p>
Add and manage hostel rooms
</p>

</div>

</a>

<a href="../manage_complaints.php"

style="
text-decoration:none;
">

<div class="card">

<h3>Complaints</h3>

<p>
Resolve student complaints
</p>

</div>

</a>

<a href="../payments/index.php"

style="
text-decoration:none;
">

<div class="card">

<h3>Payments</h3>

<p>
Manage hostel payments
</p>

</div>

</a>

</div>

</div>

</div>

</body>
</html>
