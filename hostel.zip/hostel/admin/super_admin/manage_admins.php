﻿<?php
session_start();
require_once '../../includes/db.php';

// CREATE ADMIN
if(isset($_POST['create_admin'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    mysqli_query($conn,

"INSERT INTO users
    (fullname, email, password, role)

    VALUES
    ('$fullname',
'$email',
'$password',
'admin')");
}

// DELETE ADMIN
if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    mysqli_query($conn,

"DELETE FROM users
    WHERE id='$id'
    AND role='admin'");
}

// FETCH ADMINS
$query = mysqli_query($conn,

"SELECT * FROM users
WHERE role='admin'
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Admins</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

form{
    margin-bottom:30px;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

.delete{
    background:red;
    color:white;
    padding:8px 12px;
    text-decoration:none;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>Manage Admins</h2>

<!-- CREATE ADMIN -->

<form method="POST">

<input type="text"
name="fullname"
placeholder="Full Name"
required>

<input type="email"
name="email"
placeholder="Email"
required>

<input type="password"
name="password"
placeholder="Password"
required>

<button type="submit"
name="create_admin">

Create Admin

</button>

</form>

<!-- ADMIN TABLE -->

<table>

<tr>

<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['fullname']; ?></td>

<td><?php echo $row['email']; ?></td>

<td>

<a class="delete"

href="?delete=<?php echo $row['id']; ?>">

Delete

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
