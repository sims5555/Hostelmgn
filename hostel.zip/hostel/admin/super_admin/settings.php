﻿<?php
session_start();
require_once '../../includes/db.php';

// UPDATE SETTINGS
if(isset($_POST['update'])){

    $system_name = $_POST['system_name'];
    $hostel_fee = $_POST['hostel_fee'];
    $contact_email = $_POST['contact_email'];

    mysqli_query($conn,

"UPDATE settings

    SET
    system_name='$system_name',
    hostel_fee='$hostel_fee',
    contact_email='$contact_email'

    WHERE id=1");
}

// FETCH SETTINGS
$query = mysqli_query($conn,

"SELECT * FROM settings
WHERE id=1");

$settings = mysqli_fetch_assoc($query);

?>

<!DOCTYPE html>
<html>

<head>

<title>System Settings</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    max-width:600px;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
    margin:auto;
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:5px;
}

button{
    width:100%;
    padding:12px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

</style>

</head>

<body>

<div class="container">

<h2>System Settings</h2>

<form method="POST">

<input type="text"
name="system_name"
value="<?php echo $settings['system_name']; ?>"
required>

<input type="number"
name="hostel_fee"
value="<?php echo $settings['hostel_fee']; ?>"
required>

<input type="email"
name="contact_email"
value="<?php echo $settings['contact_email']; ?>"
required>

<button type="submit"
name="update">

Update Settings

</button>

</form>

</div>

</body>
</html>
