﻿<?php
require_once "../../middleware/auth.php";
require_once "../../middleware/role.php";
require_once "../../config.php";

checkRole(['super_admin', 'hostel_admin']);

/* APPROVE APPLICATION */

if(isset($_GET['approve'])){

    $id = intval($_GET['approve']);

    // get application
    $app = $conn->query("SELECT * FROM applications WHERE id=$id")->fetch_assoc();

    $room_id = $app['room_id'];

    // get room
    $room = $conn->query("SELECT * FROM rooms WHERE id=$room_id")->fetch_assoc();

    // check capacity
    if($room['occupied'] < $room['capacity']){

        // approve application
        $conn->query("UPDATE applications SET status='approved' WHERE id=$id");

        // increase occupied count
        $newOccupied = $room['occupied'] + 1;

        // update room
        $conn->query("UPDATE rooms SET occupied=$newOccupied WHERE id=$room_id");

        // check if room is full
        if($newOccupied >= $room['capacity']){

            $conn->query("UPDATE rooms SET status='full' WHERE id=$room_id");

        }

    }

    header("Location: index.php");
    exit();

}

/* REJECT APPLICATION */

if(isset($_GET['reject'])){

    $id = intval($_GET['reject']);

    $conn->query("UPDATE applications SET status='rejected' WHERE id=$id");

    header("Location: index.php");
    exit();

}

/* FETCH APPLICATIONS */

$result = $conn->query("
SELECT applications.*,
users.fullname,
rooms.room_number

FROM applications

JOIN users ON applications.student_id = users.id
JOIN rooms ON applications.room_id = rooms.id

ORDER BY applications.applied_at DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Applications</title>
</head>
<body>

<h2>Room Applications</h2>

<table border="1" cellpadding="10">

<tr>
<th>Student</th>
<th>Room</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()) : ?>

<tr>

<td><?php echo $row['fullname']; ?></td>

<td><?php echo $row['room_number']; ?></td>

<td><?php echo $row['status']; ?></td>

<td>

<?php if($row['status'] == 'pending') : ?>

<a href="?approve=<?php echo $row['id']; ?>">Approve</a>

|

<a href="?reject=<?php echo $row['id']; ?>">Reject</a>

<?php else : ?>

Done

<?php endif; ?>

</td>

</tr>

<?php endwhile; ?>

</table>

</body>
</html>
