﻿<?php
session_start();
require_once '../includes/db.php';

// UPDATE STATUS
if(isset($_POST['update'])){

    $id = $_POST['id'];

    $status = $_POST['status'];

    mysqli_query($conn,

"UPDATE complaints
    SET status='$status'
    WHERE id='$id'");
}

// FETCH COMPLAINTS
$complaints = mysqli_query($conn,

"SELECT complaints.*,
students.fullname,
students.matric_no

FROM complaints

JOIN students
ON complaints.student_id = students.id

ORDER BY complaints.id DESC");

?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Complaints</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:30px;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2c3e50;
    color:white;
    padding:12px;
}

table td{
    padding:10px;
    border-bottom:1px solid #ddd;
}

select{
    padding:8px;
}

button{
    padding:8px 12px;
    background:#2c3e50;
    color:white;
    border:none;
}

.pending{
    color:orange;
}

.resolved{
    color:green;
}

</style>

</head>

<body>

<div class="card">

<h2>Complaint Management</h2>

<table>

<tr>

<th>ID</th>
<th>Student</th>
<th>Matric No</th>
<th>Type</th>
<th>Description</th>
<th>Status</th>
<th>Date</th>
<th>Update</th>

</tr>

<?php while($row = mysqli_fetch_assoc($complaints)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['fullname']; ?></td>

<td><?php echo $row['matric_no']; ?></td>

<td><?php echo $row['complaint_type']; ?></td>

<td><?php echo $row['description']; ?></td>

<td class="<?php echo strtolower($row['status']); ?>">

<?php echo $row['status']; ?>

</td>

<td><?php echo $row['created_at']; ?></td>

<td>

<form method="POST">

<input type="hidden"
name="id"
value="<?php echo $row['id']; ?>">

<select name="status">

<option value="Pending">
Pending
</option>

<option value="In Progress">
In Progress
</option>

<option value="Resolved">
Resolved
</option>

</select>

<button type="submit" name="update">
Update
</button>

</form>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
