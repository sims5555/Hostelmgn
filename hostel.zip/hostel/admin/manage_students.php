﻿<?php
session_start();
require_once '../includes/db.php';

// DELETE STUDENT
if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    mysqli_query($conn,

"DELETE FROM users
    WHERE id='$id'
    AND role='student'");
}

// SEARCH
$search = "";

if(isset($_GET['search'])){
    $search = $_GET['search'];
}

// FETCH STUDENTS
$query = mysqli_query($conn,

"SELECT * FROM users

WHERE role='student'

AND (

fullname LIKE '%$search%'
OR email LIKE '%$search%'

)

ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Manage Students</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

/* HEADER */

.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
    flex-wrap:wrap;
    gap:10px;
}

.top-bar h2{
    color:#1e293b;
}

/* EXPORT BUTTON */

.export-btn{
    background:green;
    color:white;
    padding:10px 15px;
    text-decoration:none;
    border-radius:5px;
}

/* SEARCH */

.search-box{
    margin-bottom:20px;
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.search-box input{
    padding:12px;
    width:300px;
    border:1px solid #ccc;
    border-radius:5px;
}

.search-box button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* TABLE */

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
    text-align:left;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f9fafb;
}

/* PROFILE IMAGE */

.profile{
    width:50px;
    height:50px;
    border-radius:50%;
    object-fit:cover;
    border:2px solid #007bff;
}

/* DELETE BUTTON */

.delete-btn{
    background:red;
    color:white;
    padding:8px 14px;
    text-decoration:none;
    border-radius:5px;
}

.no-photo{
    color:gray;
    font-size:13px;
}

</style>

</head>

<body>

<div class="container">

<!-- TOP BAR -->

<div class="top-bar">

<h2>Manage Students</h2>

<a href="export_students.php"
class="export-btn">

Export Students

</a>

</div>

<!-- SEARCH -->

<form class="search-box" method="GET">

<input type="text"
name="search"
placeholder="Search students..."
value="<?php echo $search; ?>">

<button type="submit">

Search

</button>

</form>

<!-- STUDENT TABLE -->

<table>

<tr>

<th>ID</th>
<th>Photo</th>
<th>Full Name</th>
<th>Email</th>
<th>Role</th>
<th>Action</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php if(!empty($row['photo'])){ ?>

<img
class="profile"
src="../uploads/<?php echo $row['photo']; ?>">

<?php } else { ?>

<span class="no-photo">

No Photo

</span>

<?php } ?>

</td>

<td>

<?php echo $row['fullname']; ?>

</td>

<td>

<?php echo $row['email']; ?>

</td>

<td>

<?php echo ucfirst($row['role']); ?>

</td>

<td>

<a class="delete-btn"

href="?delete=<?php echo $row['id']; ?>"

onclick="return confirm('Delete this student?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
