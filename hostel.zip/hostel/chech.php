>?php
echo "php working";
?>