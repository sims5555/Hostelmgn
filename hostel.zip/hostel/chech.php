<?php
echo "php working";
?>