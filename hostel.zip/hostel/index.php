<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Hostel Management System</title>

<style>
body {
    margin: 0;
    font-family: Arial;
    background: #f4f6f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    text-align: center;
}

h1 {
    margin-bottom: 40px;
}

a {
    display: block;
    margin: 15px;
    padding: 15px;
    background: #2c3e50;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    width: 250px;
}

a:hover {
    background: #34495e;
}
</style>
</head>

<body>

<div class="container">
<h1>Hostel Management System</h1>

<a href="login.php">?? Student Login</a>
<a href="admin_login.php">???? Admin Login</a>
</div>

</body>
</html>
<?php

session_start();

include("config.php");

$error = "";

$role = isset($_POST['role']) ? $_POST['role'] : "student";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);

    $password = trim($_POST['password']);

    if ($role == "student") {

        $query = mysqli_query($conn, "SELECT * FROM students WHERE email='$email' AND password='$password'");

        if (mysqli_num_rows($query) == 1) {

            $_SESSION['student'] = $email;

            header("Location: student/dashboard.php");

            exit();

        } else {

            $error = "Invalid Student Credentials!";

        }

    }

    if ($role == "admin") {

        $query = mysqli_query($conn, "SELECT * FROM admins WHERE email='$email' AND password='$password'");

        if (mysqli_num_rows($query) == 1) {

            $_SESSION['admin'] = $email;

            header("Location: admin/dashboard.php");

            exit();

        } else {

            $error = "Invalid Admin Credentials!";

        }

    }

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Hostel Management Login</title>

<style>

body {

    margin: 0;

    font-family: Arial;

    background: linear-gradient(135deg, #4e73df, #1cc88a);

    display: flex;

    justify-content: center;

    align-items: center;

    height: 100vh;

}

.login-box {

    background: white;

    padding: 40px;

    width: 380px;

    border-radius: 10px;

    box-shadow: 0 10px 25px rgba(0,0,0,0.2);

    text-align: center;

}

select, input {

    width: 100%;

    padding: 10px;

    margin: 10px 0;

    border-radius: 5px;

    border: 1px solid #ccc;

}

button {

    width: 100%;

    padding: 10px;

    background: #4e73df;

    border: none;

    color: white;

    font-weight: bold;

    border-radius: 5px;

    cursor: pointer;

}

button:hover {

    background: #2e59d9;

}

.error {

    color: red;

    margin-bottom: 10px;

}

</style>

</head>

<body>

<div class="login-box">

    <h2>🏠 Hostel Management System</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">

        <select name="role">

            <option value="student">Student Login</option>

            <option value="admin">Admin Login</option>

        </select>

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <button type="submit">Login</button>

    </form>

    <p><a href="register.php">Student Registration</a></p>

</div>

</body>

</html>