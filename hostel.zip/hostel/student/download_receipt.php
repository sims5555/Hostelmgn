﻿<?php
require('../includes/fpdf/fpdf.php');
require('../includes/db.php');

if (!isset($_GET['id'])) {
    die("Invalid request");
}

$id = $_GET['id'];

$result = mysqli_query($conn, "
    SELECT payments.*, users.fullname 
    FROM payments 
    JOIN users ON payments.student_id = users.id 
    WHERE payments.id = '$id'
");

$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Receipt not found");
}

$pdf = new FPDF();
$pdf->AddPage();

// LOGO
$pdf->Image('../assets/logo.png', 90, 10, 30);

// TITLE
$pdf->Ln(30);
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'GLOBAL WEALTH UNIVERSITY',0,1,'C');
$pdf->Cell(0,10,'LOME, TOGO',0,1,'C');

$pdf->Ln(5);
$pdf->Cell(0,10,'PAYMENT RECEIPT',0,1,'C');

$pdf->Ln(10);
$pdf->SetFont('Arial','',12);

// CONTENT
$pdf->Cell(50,10,'Student Name:',0);
$pdf->Cell(0,10,$data['fullname'],0,1);

$pdf->Cell(50,10,'Receipt No:',0);
$pdf->Cell(0,10,$data['receipt_no'],0,1);

$pdf->Cell(50,10,'Transaction ID:',0);
$pdf->Cell(0,10,$data['transaction_ref'],0,1);

$pdf->Cell(50,10,'Amount:',0);
$pdf->Cell(0,10,'N'.number_format($data['amount'],2),0,1);

$pdf->Cell(50,10,'Status:',0);
$pdf->Cell(0,10,$data['status'],0,1);

$pdf->Cell(50,10,'Date:',0);
$pdf->Cell(0,10,date("d M Y, h:i A", strtotime($data['paid_at'])),0,1);

// OUTPUT
$pdf->Output("D", "receipt.pdf");
