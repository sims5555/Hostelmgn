﻿<?php
session_start();
require_once '../includes/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$ref = isset($_GET['ref']) ? $_GET['ref'] : '';

$query = "SELECT * FROM payments WHERE transaction_ref='$ref'";
$result = mysqli_query($conn, $query);

$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Receipt</title>

<style>
body{
    font-family: Arial;
    background:#f4f4f4;
}

.receipt{
    width:500px;
    margin:50px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.2);
}

h2{
    text-align:center;
    color:#2c3e50;
}

p{
    font-size:18px;
    margin:10px 0;
}

.btn{
    padding:10px 20px;
    border:none;
    color:white;
    cursor:pointer;
    border-radius:5px;
    text-decoration:none;
}

.print{
    background:green;
}

.download{
    background:blue;
}

.logout{
    background:red;
}

.buttons{
    margin-top:20px;
}
</style>
</head>

<body>

<div class="receipt">

<h2>GLOBAL WEALTH UNIVERSITY</h2>
<h3 align="center">Payment Receipt</h3>

<?php if($row){ ?>

<p><b>Username:</b><?php echo $_SESSION['fullname']; ?></p>

<p><b>Amount Paid:</b> ₦<?php echo $row['amount']; ?></p>

<p><b>Transaction ID:</b><?php echo $row['transaction_ref']; ?></p>

<p><b>Status:</b><?php echo $row['status']; ?></p>

<p><b>Date:</b><?php echo $row['paid_at']; ?></p>

<div class="buttons">

<button class="btn print" onclick="window.print()">
Print
</button>

<a href="javascript:window.print()" class="btn download">
Download
</a>

<a href="../logout.php" class="btn logout">
Logout
</a>

</div>

<?php } else { ?>

<p style="color:red;text-align:center;">
Receipt Not Found
</p>

<?php } ?>

</div>

</body>
</html>
