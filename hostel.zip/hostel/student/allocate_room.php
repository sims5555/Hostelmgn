﻿<?php
session_start();
include("../config.php");

if (!isset($_SESSION['student'])) {
    header("Location: ../login.php");
    exit();
}

$email = $_SESSION['student'];

// Check if student already has room
$check = mysqli_query($conn, 
"SELECT room_number FROM students WHERE email='$email'"
);
$data = mysqli_fetch_assoc($check);

if ($data['room_number'] != "") {
    die("You already have a room allocated: " . $data['room_number']);
}

// Get available rooms
$rooms = mysqli_query($conn, 
"SELECT * FROM rooms WHERE status='available'"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $selected_room = $_POST['room'];

    // Assign room to student
    mysqli_query($conn, 
"UPDATE students SET room_number='$selected_room' WHERE email='$email'"
    );

    // Mark room as occupied
    mysqli_query($conn, 
"UPDATE rooms SET status='occupied' WHERE room_number='$selected_room'"
    );

    header("Location: profile.php");
    exit();
}
?>

<h2>Allocate Room</h2>

<form method="POST">
<select name="room" required>
<option value="">Select Room</option>
<?php while($room = mysqli_fetch_assoc($rooms)) { ?>
<option value="<?php echo $room['room_number']; ?>">
<?php echo $room['room_number']; ?>
</option>
<?php } ?>
</select>
<br><br>
<button type="submit">Allocate</button>
</form>

<br>
<a href="dashboard.php">Back to Dashboard</a>
