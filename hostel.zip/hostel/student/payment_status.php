﻿<?php
require_once "../middleware/auth.php";
require_once "../middleware/role.php";

checkRole(['student']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Status</title>
</head>
<body>

<h2>Payment Status</h2>

<p>Your payment records will appear here.</p>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>
