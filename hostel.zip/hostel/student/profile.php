﻿<?php
session_start();
include("../config.php");

if (!isset($_SESSION['student'])) {
    header("Location: ../login.php");
    exit();
}

$email = $_SESSION['student'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE email='$email'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Profile</title>
</head>
<body>

<h2>Student Profile</h2>

<p><strong>Email:</strong><?php echo $data['email']; ?></p>
<p><strong>Full Name:</strong><?php echo $data['fullname']; ?></p>
<p><strong>Room Number:</strong><?php echo $data['room_number']; ?></p>
<p><strong>Registration Date:</strong><?php echo $data['reg_date']; ?></p>

<br>
<a href="dashboard.php">Back to Dashboard</a>
<br>
<a href="../logout.php">Logout</a>

</body>
</html>
