﻿<?php
session_start();
require_once '../includes/db.php';

// SECURITY
if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

$message = "";

// UPDATE PROFILE
if(isset($_POST['update'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];

    // PHOTO UPLOAD
    if(!empty($_FILES['photo']['name'])){

        $photo_name = time() . "_" .
        $_FILES['photo']['name'];

        $tmp_name = $_FILES['photo']['tmp_name'];

        move_uploaded_file(
            $tmp_name,
"../uploads/" . $photo_name
        );

        mysqli_query($conn,

"UPDATE users
        SET photo='$photo_name'
        WHERE id='$student_id'");
    }

    // UPDATE PROFILE
    mysqli_query($conn,

"UPDATE users
    SET fullname='$fullname',
    email='$email'

    WHERE id='$student_id'");

    $_SESSION['fullname'] = $fullname;

    $message = "Profile updated successfully.";
}

// CHANGE PASSWORD
if(isset($_POST['change_password'])){

    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // GET USER
    $user_query = mysqli_query($conn,

"SELECT * FROM users
    WHERE id='$student_id'");

    $user = mysqli_fetch_assoc($user_query);

    // CHECK CURRENT PASSWORD
    if($user['password'] != $current_password){

        $message = "Current password is incorrect.";

    }elseif($new_password != $confirm_password){

        $message = "New passwords do not match.";

    }else{

        mysqli_query($conn,

"UPDATE users
        SET password='$new_password'
        WHERE id='$student_id'");

        $message = "Password changed successfully.";
    }
}

// FETCH USER
$query = mysqli_query($conn,

"SELECT * FROM users
WHERE id='$student_id'");

$user = mysqli_fetch_assoc($query);

?>

<!DOCTYPE html>
<html>

<head>

<title>My Profile</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    max-width:500px;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
    margin:auto;
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

.success{
    color:green;
    margin-bottom:15px;
}

.profile-image{
    width:120px;
    height:120px;
    border-radius:50%;
    object-fit:cover;
    margin-bottom:20px;
    border:3px solid #007bff;
}

input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    width:100%;
    padding:12px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
    margin-bottom:20px;
}

.section-title{
    margin-top:30px;
    margin-bottom:15px;
    color:#1e293b;
}

</style>

</head>

<body>

<div class="container">

<h2>My Profile</h2>

<p class="success">

<?php echo $message; ?>

</p>

<!-- PROFILE IMAGE -->

<?php if(!empty($user['photo'])){ ?>

<img class="profile-image"

src="../uploads/<?php echo $user['photo']; ?>">

<?php } ?>

<!-- UPDATE PROFILE -->

<form method="POST"
enctype="multipart/form-data">

<input type="text"
name="fullname"
value="<?php echo $user['fullname']; ?>"
required>

<input type="email"
name="email"
value="<?php echo $user['email']; ?>"
required>

<input type="file"
name="photo">

<button type="submit"
name="update">

Update Profile

</button>

</form>

<!-- CHANGE PASSWORD -->

<h3 class="section-title">

Change Password

</h3>

<form method="POST">

<input type="password"
name="current_password"
placeholder="Current Password"
required>

<input type="password"
name="new_password"
placeholder="New Password"
required>

<input type="password"
name="confirm_password"
placeholder="Confirm New Password"
required>

<button type="submit"
name="change_password">

Change Password

</button>

</form>

</div>

</body>
</html>
