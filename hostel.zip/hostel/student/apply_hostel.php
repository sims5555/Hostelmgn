﻿<?php
session_start();
require_once '../includes/db.php';

if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

$message = "";

// APPLY HOSTEL
if(isset($_POST['apply'])){

    $hostel_name = $_POST['hostel_name'];
    $room_type = $_POST['room_type'];

    mysqli_query($conn,

"INSERT INTO hostel_applications
    (student_id, hostel_name, room_type, status)

    VALUES
    ('$student_id',
'$hostel_name',
'$room_type',
'Pending')");

    // ACTIVITY LOG
    $activity = "Applied for hostel";

    mysqli_query($conn,

"INSERT INTO activity_logs
    (user_id, activity)

    VALUES
    ('$student_id','$activity')");

    $message = "Hostel application submitted successfully.";
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Apply Hostel</title>

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    max-width:500px;
}

input,
select{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
}

.success{
    color:green;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="container">

<h2>Apply For Hostel</h2>

<p class="success">

<?php echo $message; ?>

</p>

<form method="POST">

<input type="text"
name="hostel_name"
placeholder="Hostel Name"
required>

<select name="room_type" required>

<option value="">
Select Room Type
</option>

<option value="2 in a room">
2 in a room
</option>

<option value="4 in a room">
4 in a room
</option>

</select>

<button type="submit"
name="apply">

Apply

</button>

</form>

</div>

</body>
</html>
