﻿<?php
session_start();
require_once '../includes/db.php';

if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

$message = "";

// SUBMIT COMPLAINT
if(isset($_POST['submit'])){

    $type = $_POST['complaint_type'];
    $description = $_POST['description'];

    mysqli_query($conn,

"INSERT INTO complaints
    (student_id, complaint_type, description, status)

    VALUES
    ('$student_id',
'$type',
'$description',
'Pending')");

    // ACTIVITY LOG
    $activity = "Submitted a complaint";

    mysqli_query($conn,

"INSERT INTO activity_logs
    (user_id, activity)

    VALUES
    ('$student_id','$activity')");

    $message = "Complaint submitted successfully.";
}

// FETCH COMPLAINTS
$query = mysqli_query($conn,

"SELECT * FROM complaints
WHERE student_id='$student_id'
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Complaints</title>

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
}

input,
textarea{
    width:100%;
    padding:12px;
    margin-bottom:15px;
}

button{
    padding:12px 18px;
    background:#007bff;
    color:white;
    border:none;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}

table th{
    background:#1e293b;
    color:white;
    padding:15px;
}

table td{
    padding:15px;
    border-bottom:1px solid #ddd;
}

.success{
    color:green;
}

</style>

</head>

<body>

<div class="container">

<h2>My Complaints</h2>

<p class="success">

<?php echo $message; ?>

</p>

<form method="POST">

<input type="text"
name="complaint_type"
placeholder="Complaint Type"
required>

<textarea
name="description"
placeholder="Complaint Description"
required></textarea>

<button type="submit"
name="submit">

Submit Complaint

</button>

</form>

<table>

<tr>

<th>ID</th>
<th>Type</th>
<th>Description</th>
<th>Status</th>

</tr>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['complaint_type']; ?></td>

<td><?php echo $row['description']; ?></td>

<td><?php echo $row['status']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
