﻿<?php
session_start();

if (!isset($_SESSION['student'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Dashboard</title>

<style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            padding: 30px;
        }

        .card {
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .card a {
            text-decoration: none;
            color: #2c3e50;
            font-weight: bold;
        }

        .logout {
            color: red;
        }
</style>
</head>
<body>

<div class="header">
<h1>Student Dashboard</h1>
<p>Welcome <?php echo $_SESSION['student']; ?></p>
</div>

<div class="container">

<div class="card">
<a href="profile.php">👤 View Profile</a>
</div>

<div class="card">
<a href="../logout.php" class="logout">🚪 Logout</a>
</div>

</div>

</body>
</html>
