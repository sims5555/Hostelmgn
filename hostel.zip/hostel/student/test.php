﻿<?php
echo "inside student folder";
?>