﻿<?php
session_start();
require_once '../includes/db.php';

// SECURITY
if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

// UNREAD NOTIFICATIONS
$notification_query = mysqli_query($conn,

"SELECT COUNT(*) AS total
FROM notifications
WHERE student_id='$student_id'
AND status='unread'");

$notification_data = mysqli_fetch_assoc($notification_query);

$unread = $notification_data['total'];

?>

<!DOCTYPE html>
<html>

<head>

<title>Student Dashboard</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
}

.container{
    display:flex;
    min-height:100vh;
}

.sidebar{
    width:250px;
    background:#1e293b;
    padding-top:20px;
}

.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    padding:15px 25px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#334155;
    padding-left:35px;
}

.main{
    flex:1;
    padding:30px;
}

.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

.badge{
    background:red;
    color:white;
    padding:3px 8px;
    border-radius:50%;
    font-size:12px;
    margin-left:8px;
}

</style>

</head>

<body>

<div class="container">

<!-- SIDEBAR -->

<div class="sidebar">

<div style="text-align:center; color:white; margin-bottom:30px;">

<?php

$user_query = mysqli_query($conn,

"SELECT * FROM users
WHERE id='$student_id'");

$user = mysqli_fetch_assoc($user_query);

?>

<?php if(!empty($user['photo'])){ ?>

<img
src="../uploads/<?php echo $user['photo']; ?>"

style="
width:80px;
height:80px;
border-radius:50%;
object-fit:cover;
margin-bottom:10px;
border:3px solid white;
">

<?php } ?>

<h2>

<?php echo $user['fullname']; ?>

</h2>

</div>


<a href="index.php">
Dashboard
</a>

<a href="profile.php">
profile
</a>


<a href="apply_hostel.php">
Apply Hostel
</a>

<a href="complaints.php">
Complaints
</a>

<a href="visitor_request.php">
Visitors
</a>

<a href="my_room.php">
My Room
</a>

<a href="notifications.php">
Notifications
</a>
<a href="announcements.php">
announcement
</a>
<?php if($unread > 0){ ?>

<span class="badge">

<?php echo $unread; ?>

</span>

<?php } ?>

</a>

<a href="profile.php">
Profile
</a>

<a href="../logout.php">
Logout
</a>

</div>

<!-- MAIN -->

<div class="main">

<div class="card">

<h1>Welcome Student</h1>

<p>
Your Hostel Management Dashboard
</p>

</div>

</div>

</div>

</body>
</html>
