﻿<?php
session_start();
require_once '../includes/db.php';

// FETCH ANNOUNCEMENTS
$query = mysqli_query($conn,

"SELECT * FROM announcements
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Announcements</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
}

.announcement{
    background:#f8fafc;
    padding:20px;
    margin-bottom:20px;
    border-left:5px solid #007bff;
}

.time{
    color:gray;
    margin-top:10px;
}

</style>

</head>

<body>

<div class="container">

<h2>Hostel Announcements</h2>

<?php while($row = mysqli_fetch_assoc($query)) { ?>

<div class="announcement">

<h3>

<?php echo $row['title']; ?>

</h3>

<p>

<?php echo $row['message']; ?>

</p>

<div class="time">

<?php echo $row['created_at']; ?>

</div>

</div>

<?php } ?>

</div>

</body>
</html>
