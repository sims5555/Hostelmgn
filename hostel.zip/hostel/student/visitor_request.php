﻿<?php
session_start();
require_once '../includes/db.php';

// SECURITY
if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

if(isset($_POST['submit'])){

    $visitor_name = $_POST['visitor_name'];
    $phone = $_POST['phone'];
    $visit_date = $_POST['visit_date'];

    mysqli_query($conn,

"INSERT INTO visitors
    (student_id, visitor_name, phone, visit_date, status)

    VALUES
    ('$student_id',
'$visitor_name',
'$phone',
'$visit_date',
'Pending')");

    echo "<script>
    alert('Visitor request submitted');
</script>";
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Visitor Request</title>

<style>

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    width:400px;
    margin:auto;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

input{
    width:100%;
    padding:12px;
    margin-top:10px;
    margin-bottom:15px;
}

button{
    width:100%;
    padding:12px;
    background:#007bff;
    color:white;
    border:none;
    cursor:pointer;
}

</style>

</head>

<body>

<div class="container">

<h2>Visitor Request</h2>

<form method="POST">

<input type="text"
name="visitor_name"
placeholder="Visitor Name"
required>

<input type="text"
name="phone"
placeholder="Phone Number"
required>

<input type="date"
name="visit_date"
required>

<button type="submit" name="submit">

Submit Request

</button>

</form>

</div>

</body>
</html>
