﻿<?php
session_start();
require_once '../includes/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get values
    $student_id = $_SESSION['user_id'];
    $amount = $_POST['amount'];

    // Generate transaction ID
    $transaction_ref = "TXN" . time();

    // Generate receipt number
    $receipt_no = "GWU-" . rand(1000,9999);

    // Payment status
    $status = "Completed";

    // Save into database
    $query = "INSERT INTO payments 
    (student_id, receipt_no, transaction_ref, amount, status, paid_at)

    VALUES

    ('$student_id', '$receipt_no', '$transaction_ref', '$amount', '$status', NOW())";

    $result = mysqli_query($conn, $query);

    // Check insert
    if ($result) {

        // Redirect to receipt
        header("Location: receipt.php?ref=$transaction_ref");
        exit();

    } else {

        $message = "Payment Failed: " . mysqli_error($conn);

    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment</title>

<style>

body{
    font-family: Arial;
    background:#f4f4f4;
}

.payment-box{
    width:400px;
    margin:80px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.2);
    text-align:center;
}

h2{
    color:#2c3e50;
}

input{
    width:90%;
    padding:12px;
    margin:15px 0;
}

button{
    background:green;
    color:white;
    padding:12px 20px;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

.error{
    color:red;
}

</style>

</head>

<body>

<div class="payment-box">

<h2>Hostel Fee Payment</h2>

<?php if($message != ""){ ?>
<p class="error"><?php echo $message; ?></p>
<?php } ?>

<form method="POST">

<input type="number"
       name="amount"
       placeholder="Enter Amount"
       required>

<br>

<button type="submit">
Pay Now
</button>

</form>

</div>

</body>
</html>
