﻿<?php
require_once '../includes/db.php';
require_once '../includes/dompdf/autoload.inc.php';

use Dompdf\Dompdf;

$ref =isset('$_GET['ref']) ? $_get['ref'] : '';

$query = "
    SELECT payments.*, students.name 
    FROM payments 
    JOIN students ON payments.student_id = students.id
    WHERE payments.transaction_ref = '$ref'
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}

$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("Receipt not found!");
}

// HTML content
$html = '
<h2 style="text-align:center;">GLOBAL WEALTH UNIVERSITY</h2>
<p style="text-align:center;">Lomé, Togo</p>

<h3 style="text-align:center;">Payment Receipt</h3>

<p><strong>Student:</strong>'.$row['name'].'</p>
<p><strong>Receipt No:</strong>'.$row['receipt_no'].'</p>
<p><strong>Transaction ID:</strong>'.$row['transaction_ref'].'</p>
<p><strong>Amount:</strong> ₦'.number_format($row['amount'],2).'</p>
<p><strong>Status:</strong>'.$row['status'].'</p>
<p><strong>Date:</strong>'.$row['paid_at'].'</p>
';

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("receipt.pdf", ["Attachment" => true]);

