﻿<?php
session_start();
require_once '../includes/db.php';

// CHECK LOGIN
if(!isset($_SESSION['user_id'])){
    die("Student not logged in");
}

$student_id = $_SESSION['user_id'];

// FETCH ROOM DETAILS
$query = mysqli_query($conn, "

SELECT allocations.*, rooms.room_number

FROM allocations

JOIN rooms
ON allocations.room_id = rooms.id

WHERE allocations.student_id='$student_id'

ORDER BY allocations.id DESC

LIMIT 1

");

$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>

<head>

<title>My Room</title>

<style>

body{
    font-family:Arial;
    background:#f4f4f4;
    padding:20px;
}

.card{
    width:500px;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
}

.info{
    margin-bottom:15px;
    font-size:18px;
}

.label{
    font-weight:bold;
}

.notfound{
    color:red;
    font-size:18px;
}

</style>

</head>

<body>

<div class="card">

<h2>My Room Details</h2>

<?php if($data){ ?>

<div class="info">
<span class="label">Hostel:</span>
<?php echo $data['hostel_name']; ?>
</div>

<div class="info">
<span class="label">Room Number:</span>
<?php echo $data['room_number']; ?>
</div>

<div class="info">
<span class="label">Allocation Date:</span>
<?php echo $data['created_at']; ?>
</div>

<?php } else { ?>

<div class="notfound">
No room allocated yet.
</div>

<?php } ?>

</div>

</body>
</html>
