﻿<?php
require_once "../middleware/auth.php";
require_once "../middleware/role.php";

checkRole(['student']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Hostel Details</title>
</head>
<body>

<h2>My Hostel Details</h2>

<p>Your hostel information will appear here.</p>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>
