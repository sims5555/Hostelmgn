﻿<?php
session_start();
require_once '../includes/db.php';

// SECURITY
if(!isset($_SESSION['user_id'])){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

// MARK ALL AS READ
mysqli_query($conn,

"UPDATE notifications
SET status='read'
WHERE student_id='$student_id'
AND status='unread'");

// FETCH NOTIFICATIONS
$query = mysqli_query($conn,

"SELECT * FROM notifications
WHERE student_id='$student_id'
ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

<title>Notifications</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#1e293b;
}

.notification{
    padding:15px;
    margin-bottom:15px;
    background:#f8fafc;
    border-left:5px solid #007bff;
    border-radius:5px;
}

.time{
    margin-top:10px;
    color:gray;
    font-size:13px;
}

.empty{
    color:gray;
}

</style>

</head>

<body>

<div class="container">

<h2>My Notifications</h2>

<?php

if(mysqli_num_rows($query) > 0){

    while($row = mysqli_fetch_assoc($query)){

?>

<div class="notification">

<p>

<?php echo $row['message']; ?>

</p>

<div class="time">

<?php echo $row['created_at']; ?>

</div>

</div>

<?php

    }

}else{

    echo "<p class='empty'>
    No notifications yet.
</p>";
}

?>

</div>

</body>
</html>
